#pragma once

#include "AST.h"

AST getExampleAST();