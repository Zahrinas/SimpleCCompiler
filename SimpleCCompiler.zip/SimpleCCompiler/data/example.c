#include<stdio.h>

int main__() {
    int a, b;
    scanf_s("%d%d", &a, &b);
    printf("%d", a + b);
    scanf_s(" ");
    return 0;
}